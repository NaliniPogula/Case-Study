using OnlineBankingDashboard;

var builder = WebApplication.CreateBuilder(args);
var app = Startup.InitializeApp(args);
app.Run();